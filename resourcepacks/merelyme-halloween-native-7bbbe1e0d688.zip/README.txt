MerelyMeSMP Visual Test v2

Client test pack for Minecraft 1.21.11 Fabric + OptiGUI.
Based on MerelyMeSMP-Menu-Ranks-BanHammer-v5.1-Fixed.
The BanHammer assets are preserved.

The blue GUI replaces every 6-row chest while this local test pack is enabled. This is required because OptiGUI 2.3 cannot title-match a server-created virtual inventory. Disable the pack to restore normal 6-row chests.

Cosmetic samples (paper CustomModelData):
9000 Angel Wings; 9002 BlueFire Wings; 9011 Phoenix Wings
10000 Diving Helmet; 10003 Military Helmet; 10005 Pot Hat
11000 Common Crate; 11001 Legendary Crate

12000 Animated Earth source (static item preview)

The crate samples are static item previews. Their Blockbench animations need a server model/cosmetics plugin for playback.
