// ─────────────────────────────────────────────────────────────────────────────
//  technotypist_lib.glsl — portable math / colour / noise helpers.
//
//  Written in the intersection of GLSL 1.50 (Minecraft core shaders), GLSL 3.30
//  (1.26+ core shaders) and GLSL ES 3.00 (the WebGL2 preview in the TechnoTypist
//  dashboard), so the EXACT same source compiles in the game and in the browser.
//  Nothing in here touches a uniform or a sampler — keep it that way.
// ─────────────────────────────────────────────────────────────────────────────
#ifndef TECHNOTYPIST_LIB_INCLUDED
#define TECHNOTYPIST_LIB_INCLUDED

#ifndef PI
#define PI 3.14159265359
#endif
#ifndef TAU
#define TAU 6.28318530718
#endif

/* ── Colour construction ─────────────────────────────────────────────────── */

/** 0-255 sRGB triplet → shader colour. `rgb(255, 80, 0)`. */
vec3 rgb(int r, int g, int b) {
    return vec3(float(r) / 255.0, float(g) / 255.0, float(b) / 255.0);
}

vec4 rgba(int r, int g, int b, int a) {
    return vec4(float(r) / 255.0, float(g) / 255.0, float(b) / 255.0, float(a) / 255.0);
}

vec3 hsv_to_rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

vec3 rgb_to_hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + 1.0e-10)), d / (q.x + 1.0e-10), q.x);
}

/** Hue/sat/value in degrees + percent: `hsv(210, 80, 100)`. */
vec3 hsv(int h, int s, int v) {
    return hsv_to_rgb(vec3(float(h) / 360.0, float(s) / 100.0, float(v) / 100.0));
}

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 lighten(vec3 c, float amount) {
    return clamp(mix(c, vec3(1.0), clamp(amount, 0.0, 1.0)), 0.0, 1.0);
}

vec3 darken(vec3 c, float amount) {
    return clamp(mix(c, vec3(0.0), clamp(amount, 0.0, 1.0)), 0.0, 1.0);
}

vec3 saturate_color(vec3 c, float amount) {
    return clamp(mix(vec3(luma(c)), c, max(0.0, 1.0 + amount)), 0.0, 1.0);
}

/* ── Gamma-correct mixing ────────────────────────────────────────────────── */

vec3 to_linear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 to_gamma(vec3 c)  { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

/** Blends two colours through linear space — no muddy grey halfway point.
 *  Use this instead of mix() whenever two saturated hues meet in a gradient. */
vec3 blend(vec3 a, vec3 b, float t) {
    return to_gamma(mix(to_linear(a), to_linear(b), clamp(t, 0.0, 1.0)));
}

/* ── Hashes & noise ──────────────────────────────────────────────────────── */

float fx_hash(float n) {
    return fract(sin(n * 12.9898) * 43758.5453);
}

float fx_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

/** Smooth value noise, 0..1. */
float fx_noise(float x) {
    float i = floor(x);
    float f = fract(x);
    return mix(fx_hash(i), fx_hash(i + 1.0), f * f * (3.0 - 2.0 * f));
}

float fx_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(fx_hash(i), fx_hash(i + vec2(1.0, 0.0)), f.x),
        mix(fx_hash(i + vec2(0.0, 1.0)), fx_hash(i + vec2(1.0, 1.0)), f.x),
        f.y);
}

/** Fractal (layered) noise, 0..1. `octaves` is clamped to 1..5. */
float fx_fbm(vec2 p, int octaves) {
    float sum = 0.0;
    float amp = 0.5;
    float norm = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= octaves) break;
        sum += fx_noise(p) * amp;
        norm += amp;
        p *= 2.02;
        amp *= 0.5;
    }
    return norm > 0.0 ? sum / norm : 0.0;
}

float fx_fbm(vec2 p) { return fx_fbm(p, 3); }

/* ── Easing & shaping ────────────────────────────────────────────────────── */

float ease_in(float t)     { t = clamp(t, 0.0, 1.0); return t * t; }
float ease_out(float t)    { t = clamp(t, 0.0, 1.0); return 1.0 - (1.0 - t) * (1.0 - t); }
float ease_in_out(float t) { t = clamp(t, 0.0, 1.0); return t * t * (3.0 - 2.0 * t); }

/** A 0..1 triangle wave — rises then falls, no discontinuity. */
float ping_pong(float t) { return abs(fract(t) * 2.0 - 1.0); }

/** A 0..1 sine wave (instead of -1..1). */
float wave01(float t) { return sin(t * TAU) * 0.5 + 0.5; }

vec2 rotate2(vec2 p, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec2(p.x * c - p.y * s, p.x * s + p.y * c);
}

/* ── Effect id ───────────────────────────────────────────────────────────── */

/**
 * Packs a colour into the 32-bit id the effect dispatcher switches on. The three
 * channels are rounded to bytes, so an id is exact and comparison-safe.
 */
uint technotypist_color_id(vec3 col) {
    uint r = uint(round(clamp(col.r, 0.0, 1.0) * 255.0));
    uint g = uint(round(clamp(col.g, 0.0, 1.0) * 255.0));
    uint b = uint(round(clamp(col.b, 0.0, 1.0) * 255.0));
    return (r << 24) | (g << 16) | (b << 8) | 255u;
}

#endif
