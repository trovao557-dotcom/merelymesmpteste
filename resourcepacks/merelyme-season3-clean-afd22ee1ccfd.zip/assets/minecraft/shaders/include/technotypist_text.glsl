// ---------------------------------------------------------------------------
//  technotypist_text.glsl - Minecraft plumbing for the TechnoTypist text-effect engine.
//
//  Include this from a text core shader AFTER its ins/outs/uniforms are declared,
//  then make main() start with:
//
//      if (technotypist_text_shader()) return;
//
//  in BOTH the vertex and the fragment stage. Everything else (glyph quad
//  reconstruction, effect dispatch, compositing, fog) happens in here.
//
//  The host shader must already declare, per stage:
//    VSH  Position, Color, UV0, ProjMat, ModelViewMat, GameTime, Sampler0,
//         vertexColor, texCoord0, baseColor, lightColor
//         and (1.21.6+) sphericalVertexDistance / cylindricalVertexDistance,
//         or (older) vertexDistance.
//    FSH  Sampler0, GameTime, ColorModulator, fog uniforms, texCoord0,
//         baseColor, lightColor, fragColor.
//
//  Version switches the host sets:
//    IS_1_21_6         1.21.6+ shader interfaces (dynamictransforms / globals).
//    IS_GUI            no fog, no lightmap (1.26+ shader variant).
//    IS_SEE_THROUGH    see-through text variant (1.26+).
//    IS_GRAYSCALE      single-channel font atlas (1.26+).
//    CDL_LOC(n)        26.3+: expands to layout(location = n) — the separate
//                      shader objects there need every varying located. The
//                      host owns 0–5, these carriers take 6–15 (16 is the
//                      floor on macOS, hence the packed flags).
//    TECHNOTYPIST_HOST_FOG  the host applies fog / OIT itself (26.3+).
//    CDL_VERTEX_ID     the vertex's index within its own draw. 26.2+ packs every
//                      GUI draw into one shared vertex buffer and draws with a
//                      base vertex, so raw gl_VertexID % 4 no longer names the
//                      glyph corner; those hosts define this as
//                      (gl_VertexID - gl_BaseVertexARB).
//    TECHNOTYPIST_NO_EXPAND the corner is unknowable (26.2+ without
//                      GL_ARB_shader_draw_parameters): never grow the quad, so
//                      halos clip to the glyph instead of tearing it apart.
// ---------------------------------------------------------------------------
#ifndef TECHNOTYPIST_TEXT_INCLUDED
#define TECHNOTYPIST_TEXT_INCLUDED

#ifndef CDL_LOC
#define CDL_LOC(n)
#endif

#ifndef CDL_VERTEX_ID
#define CDL_VERTEX_ID gl_VertexID
#endif

#if defined(RENDERTYPE_TEXT) || defined(RENDERTYPE_TEXT_INTENSITY) || defined(IS_GRAYSCALE)

#moj_import <technotypist_lib.glsl>
#moj_import <technotypist_fx.glsl>
#moj_import <technotypist_helpers.glsl>

/* ---------------------------------------------------------------------------
   Effect dispatch.

   An effect is addressed by the text colour it is written in. Minecraft derives
   a drop shadow as (channel & 0xFC) >> 2, i.e. exactly channel / 4 for channels
   that are multiples of four - so quantising the main colour by 4 and reading
   the shadow colour raw land on the SAME key. That is why every effect colour
   must have channels divisible by 4.
   --------------------------------------------------------------------------- */

#define TECHNOTYPIST_EFFECT(r, g, b) return true; case ((uint(r / 4) << 16) | (uint(g / 4) << 8) | uint(b / 4)):

bool technotypist_dispatch() {
    uint id = technotypist_color_id(floor(round(fx.color.rgb * 255.0) / 4.0) / 255.0);
    if (fx.isShadow) id = technotypist_color_id(fx.color.rgb);

    // The trigger colour is an ADDRESS, not a colour anyone chose to look at, so a
    // matched effect paints from a neutral base and one that sets no colour of its
    // own renders white with a proper dark shadow rather than the raw trigger hex.
    //
    // The original is kept: this function is called TWICE when the shadow test
    // misreads a glyph, and the second call has to see the untouched vertex colour
    // or it can never match anything.
    vec4 incoming = fx.color;
    fx.color.rgb = fx.isShadow ? vec3(0.25) : vec3(1.0);

    switch (id >> 8) {
        case 0xFFFFFFFFu:

#moj_import <technotypist_effects.glsl>

        return true;
    }

    fx.color = incoming;
    return false;
}

/* ------------------------------------------------------------------------- */

#ifdef VSH

CDL_LOC(6) out vec4 cdl_screen;
// x = active, y = shadow, z = expanded.
CDL_LOC(7) flat out vec3 cdl_flags;

// One-hot corner carriers. Each vertex writes its own clip position / uv into
// its own varying and leaves the other three at zero; because the missing
// vertex of a triangle interpolates to EXACTLY zero, the fragment stage can
// tell "not part of this triangle" from "weight happens to be small" and
// rebuild the glyph quad without ever dividing by zero.
CDL_LOC(8) out vec3 cdl_p0;
CDL_LOC(9) out vec3 cdl_p1;
CDL_LOC(10) out vec3 cdl_p2;
CDL_LOC(11) out vec3 cdl_p3;
CDL_LOC(12) out vec3 cdl_u0;
CDL_LOC(13) out vec3 cdl_u1;
CDL_LOC(14) out vec3 cdl_u2;
CDL_LOC(15) out vec3 cdl_u3;

bool technotypist_text_shader() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    cdl_flags = vec3(1.0, fract(Position.z) < 0.01 ? 1.0 : 0.0, 0.0);

    fx.isShadow = cdl_flags.y > 0.5;
    fx.color = Color;
    fx.expand = false;
    fx.time = GameTime * 1200.0;

    if (!technotypist_dispatch()) {
        // The z heuristic can mislabel an ordinary glyph as a shadow; retry once
        // on the quantised (main colour) path before giving up on this vertex.
        cdl_flags.y = 0.0;
#ifdef IS_1_21_6
        if (fx.isShadow) {
#else
        if (Position.z == 0.0 && fx.isShadow) {
#endif
            fx.isShadow = false;
            if (!technotypist_dispatch()) {
                cdl_flags.x = 0.0;
                return false;
            }
        } else {
            cdl_flags.x = 0.0;
            return false;
        }
    }

    // Effects address the atlas in whole pixels; anything but the standard
    // 256x256 font sheet (a resource pack with a high-res font) would smear, so
    // fall through to vanilla rendering instead.
    if (textureSize(Sampler0, 0) != ivec2(256, 256)) {
        cdl_flags.x = 0.0;
        return false;
    }

    cdl_p0 = cdl_p1 = cdl_p2 = cdl_p3 = vec3(0.0);
    cdl_u0 = cdl_u1 = cdl_u2 = cdl_u3 = vec3(0.0);
    int cdlCorner = (CDL_VERTEX_ID) % 4;
    switch (cdlCorner) {
        case 0: cdl_p0 = vec3(gl_Position.xy, 1.0); cdl_u0 = vec3(UV0, 1.0); break;
        case 1: cdl_p1 = vec3(gl_Position.xy, 1.0); cdl_u1 = vec3(UV0, 1.0); break;
        case 2: cdl_p2 = vec3(gl_Position.xy, 1.0); cdl_u2 = vec3(UV0, 1.0); break;
        case 3: cdl_p3 = vec3(gl_Position.xy, 1.0); cdl_u3 = vec3(UV0, 1.0); break;
    }

#ifndef TECHNOTYPIST_NO_EXPAND
    if (fx.expand) {
        // Grow the quad so outlines, glows, particles and motion have somewhere to
        // land; everything outside the glyph is discarded in the fragment stage.
        //
        // The padding is measured in GLYPH PIXELS, not in a fixed slice of the
        // screen: project two unit steps of the text's own space and use them as
        // the pixel-to-clip scale. That keeps the halo the same visual size at any
        // GUI scale and on world-space text (nameplates, holograms, signs), and it
        // keeps the overdraw proportional to the glyph instead of the window.
        vec4 origin = ProjMat * ModelViewMat * vec4(Position, 1.0);
        vec4 stepX = ProjMat * ModelViewMat * vec4(Position + vec3(1.0, 0.0, 0.0), 1.0);
        vec4 stepY = ProjMat * ModelViewMat * vec4(Position + vec3(0.0, 1.0, 0.0), 1.0);
        vec2 base = origin.xy / origin.w;
        vec2 perPixel = abs(stepX.xy / stepX.w - base) + abs(stepY.xy / stepY.w - base);

        vec2 corner = vec2[4](vec2(-1.0, 1.0), vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0))[cdlCorner];
        gl_Position.xy += corner * perPixel * TECHNOTYPIST_PADDING * gl_Position.w;
        cdl_flags.z = 1.0;
    }
#endif

    cdl_screen = gl_Position;

#if defined(IS_1_21_6) && !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#elif !defined(IS_1_21_6)
    vec4 technotypistViewPos = ModelViewMat * vec4(Position, 1.0);
    vertexDistance = FogShape == 0
        ? length(technotypistViewPos.xyz)
        : max(length(technotypistViewPos.xz), abs(technotypistViewPos.y));
#endif

    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;
    return true;
}

#endif

/* ------------------------------------------------------------------------- */

#ifdef FSH

CDL_LOC(6) in vec4 cdl_screen;
CDL_LOC(7) flat in vec3 cdl_flags;

CDL_LOC(8) in vec3 cdl_p0;
CDL_LOC(9) in vec3 cdl_p1;
CDL_LOC(10) in vec3 cdl_p2;
CDL_LOC(11) in vec3 cdl_p3;
CDL_LOC(12) in vec3 cdl_u0;
CDL_LOC(13) in vec3 cdl_u1;
CDL_LOC(14) in vec3 cdl_u2;
CDL_LOC(15) in vec3 cdl_u3;

/** Folds one one-hot corner carrier into the running min/max, if it is present. */
void cdl_extend(vec3 carrier, inout vec2 lo, inout vec2 hi) {
    if (carrier.z <= 0.00001) return;
    vec2 p = carrier.xy / carrier.z;
    lo = min(lo, p);
    hi = max(hi, p);
}

bool technotypist_text_shader() {
    if (cdl_flags.x < 0.5) return false;

    fx.isShadow = cdl_flags.y > 0.5;
    fx.color = baseColor;
    fx.topColor = vec4(0.0);
    fx.backColor = vec4(0.0);
    fx.sampleGlyph = true;
    fx.expand = false;
    fx.time = GameTime * 1200.0;

    vec2 innerMin = vec2(1.0e9);
    vec2 innerMax = vec2(-1.0e9);
    cdl_extend(cdl_p0, innerMin, innerMax);
    cdl_extend(cdl_p1, innerMin, innerMax);
    cdl_extend(cdl_p2, innerMin, innerMax);
    cdl_extend(cdl_p3, innerMin, innerMax);

    vec2 uvMin = vec2(1.0e9);
    vec2 uvMax = vec2(-1.0e9);
    cdl_extend(cdl_u0, uvMin, uvMax);
    cdl_extend(cdl_u1, uvMin, uvMax);
    cdl_extend(cdl_u2, uvMin, uvMax);
    cdl_extend(cdl_u3, uvMin, uvMax);

    // If no corner carrier survived (a fragment landing exactly on a triangle
    // edge), fall back to the interpolated coordinate instead of dividing by a
    // degenerate quad and discarding the glyph.
    if (innerMax.x < innerMin.x || uvMax.x < uvMin.x) {
        innerMin = cdl_screen.xy;
        innerMax = cdl_screen.xy + vec2(1.0e-4);
        uvMin = texCoord0;
        uvMax = texCoord0 + vec2(1.0e-6);
    }

    vec2 innerSize = max(innerMax - innerMin, vec2(1.0e-6));
    vec2 uvSize = max(uvMax - uvMin, vec2(1.0e-9));

    fx.uvMin = uvMin;
    fx.uvMax = uvMax;
    fx.uvSize = uvSize;
    fx.uvCenter = uvMin + 0.5 * uvSize;

    fx.local = (cdl_screen.xy - innerMin) / innerSize;
    fx.local.y = 1.0 - fx.local.y;
    fx.uv = fx.local * uvSize + uvMin;
    // An unexpanded quad has no sub-pixel slack, so the interpolated atlas
    // coordinate is exact and cheaper than the reconstruction above.
    if (cdl_flags.z < 0.5) fx.uv = texCoord0;

    fx.position = cdl_screen.xy * uvSize * 256.0 / innerSize;
    fx.charPos = 0.5 * (innerMin + innerMax) * uvSize * 256.0 / innerSize;
    if (fx.isShadow) {
        // Undo Minecraft's +1,+1 shadow offset so a gradient lines up with the
        // glyph it belongs to instead of drifting one pixel per pass.
        fx.charPos += vec2(-1.0, 1.0);
        fx.position += vec2(-1.0, 1.0);
    }

    technotypist_dispatch();

    if (fx_outside(fx.uv)) fx.sampleGlyph = false;

    vec4 texel = texture(Sampler0, fx.uv);
#if defined(RENDERTYPE_TEXT_INTENSITY) || defined(IS_GRAYSCALE)
    texel = texel.rrrr;
#endif
    if (!fx.sampleGlyph) texel = vec4(0.0);

    fx.topColor.a *= texel.a;

    fragColor = mix(vec4(fx.backColor.rgb, fx.backColor.a * fx.color.a), texel * fx.color, texel.a);
    fragColor.rgb = mix(fragColor.rgb, fx.topColor.rgb, fx.topColor.a);
    fragColor *= lightColor * ColorModulator;

    if (fragColor.a < 0.1) discard;

#if defined(TECHNOTYPIST_HOST_FOG)
    // The host finishes the colour (fog / OIT).
#elif defined(IS_1_21_6) && !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    fragColor = apply_fog(
        fragColor,
        sphericalVertexDistance,
        cylindricalVertexDistance,
        FogEnvironmentalStart,
        FogEnvironmentalEnd,
        FogRenderDistanceStart,
        FogRenderDistanceEnd,
        FogColor);
#elif !defined(IS_1_21_6)
    fragColor = linear_fog(fragColor, vertexDistance, FogStart, FogEnd, FogColor);
#endif

    return true;
}

#endif

#else

// The host shader is not a text render type - nothing to do.
bool technotypist_text_shader() { return false; }

#endif
#endif
