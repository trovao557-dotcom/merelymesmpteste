#version 150
#define VSH
#define RENDERTYPE_TEXT

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform sampler2D Sampler0;
uniform sampler2D Sampler2;
uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 baseColor;
out vec4 lightColor;

#moj_import <technotypist_text.glsl>

void main() {
    baseColor = Color;
    lightColor = texelFetch(Sampler2, UV2 / 16, 0);

    if (technotypist_text_shader()) return;

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vec4 viewPos = ModelViewMat * vec4(Position, 1.0);
    vertexDistance = FogShape == 0 ? length(viewPos.xyz) : max(length(viewPos.xz), abs(viewPos.y));

    vertexColor = Color * lightColor;
    texCoord0 = UV0;
}
