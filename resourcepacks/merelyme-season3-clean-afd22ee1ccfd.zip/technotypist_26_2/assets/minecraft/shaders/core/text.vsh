#version 330
#extension GL_ARB_shader_draw_parameters : enable
#ifdef GL_ARB_shader_draw_parameters
#define CDL_VERTEX_ID (gl_VertexID - gl_BaseVertexARB)
#else
#define TECHNOTYPIST_NO_EXPAND
#endif

#define VSH
#define RENDERTYPE_TEXT
#define IS_1_21_6

#ifdef IS_GRAYSCALE
#define RENDERTYPE_TEXT_INTENSITY
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

uniform sampler2D Sampler0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
out vec4 baseColor;
out vec4 lightColor;

#moj_import <technotypist_text.glsl>

void main() {
    baseColor = Color;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    lightColor = sample_lightmap(Sampler2, UV2);
#else
    lightColor = vec4(1.0);
#endif

    if (technotypist_text_shader()) return;

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color * lightColor;
    texCoord0 = UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif
}
