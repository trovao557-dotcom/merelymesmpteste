// ---------------------------------------------------------------------------
//  technotypist_fx.glsl - the TechnoTypist text-effect library.
//
//  Every effect an author (or the AI) writes is a short block of calls into the
//  functions below, operating on the global `fx` state for the fragment being
//  shaded. The file is deliberately free of Minecraft plumbing: it only needs
//  `Sampler0` (the 256x256 font atlas) and `GameTime` to exist, which is true in
//  every Minecraft text shader AND in the dashboard WebGL2 preview - so what you
//  see in the browser is the same code the game runs.
//
//  Coordinate conventions
//  ----------------------
//  fx.local      (0,0) top-left .. (1,1) bottom-right of the glyph quad.
//  fx.uv         atlas coordinate actually sampled. Move it to move the glyph.
//  fx.uvMin/Max  the glyph cell in the atlas. 1 glyph pixel = FX_PX in uv.
//  fx.position   screen position in glyph-pixels (a character is 8 tall).
//  fx.charPos    the centre of this character, in the same glyph-pixel units.
//                Use it for anything that must vary per CHARACTER, not per pixel.
//  fx.time       seconds since the world loaded. All `speed` arguments are
//                cycles per second, so speed = 1.0 means one loop per second.
// ---------------------------------------------------------------------------
#ifndef TECHNOTYPIST_FX_INCLUDED
#define TECHNOTYPIST_FX_INCLUDED

/** One pixel in the current atlas, in UV units. */
#define FX_PX (vec2(1.0) / vec2(textureSize(Sampler0, 0)))

/** Glyph pixels of headroom an effect gets around each character. */
#define TECHNOTYPIST_PADDING 6.0

struct TechnotypistText {
    /** The glyph colour, multiplied over the sampled glyph pixel. */
    vec4 color;
    /** Drawn OVER the glyph. `.a` is the blend amount (0 = invisible). */
    vec4 topColor;
    /** Drawn BEHIND / around the glyph - outlines, glows, flames, particles. */
    vec4 backColor;
    vec2 position;
    vec2 charPos;
    vec2 local;
    vec2 uv;
    vec2 uvMin;
    vec2 uvMax;
    vec2 uvSize;
    vec2 uvCenter;
    /** True on the drop-shadow pass. Most decorations skip it. */
    bool isShadow;
    /** Cleared automatically when `uv` lands outside the glyph cell. */
    bool sampleGlyph;
    /** Set by any effect that draws or moves outside the glyph quad. */
    bool expand;
    /** Seconds. */
    float time;
};

TechnotypistText fx;

/* -- Sampling helpers ---------------------------------------------------- */

/** True when `uv` is outside this glyph cell (or NaN). */
bool fx_outside(vec2 uv) {
    if (isnan(uv.x) || isnan(uv.y)) return true;
    const float e = 0.0001;
    return uv.x < fx.uvMin.x + e || uv.y < fx.uvMin.y + e
        || uv.x > fx.uvMax.x - e || uv.y > fx.uvMax.y - e;
}

/** Coverage of the glyph at `uv`, 0 outside the cell. */
float fx_glyph(vec2 uv) {
    if (fx_outside(uv)) return 0.0;
    return texture(Sampler0, uv).a;
}

/** Coverage `offsetPixels` glyph-pixels away from the current fragment. */
float fx_glyph_at(vec2 offsetPixels) {
    return fx_glyph(fx.uv + offsetPixels * FX_PX);
}

/** Row inside the glyph, 0 (top) .. 7 (bottom). */
float fx_row() { return floor((fx.uv.y - fx.uvMin.y) * float(textureSize(Sampler0, 0).y)); }

/** Column inside the glyph, 0 = leftmost pixel. */
float fx_col() { return floor((fx.uv.x - fx.uvMin.x) * float(textureSize(Sampler0, 0).x)); }

/** Sub-pixel position inside the current glyph pixel, 0..1. */
vec2 fx_subpixel() { return fract(fx.uv * vec2(textureSize(Sampler0, 0))); }

/** Index of this character along the line (0, 1, 2, ...). */
float fx_char_index() { return floor(fx.charPos.x / 6.0); }

/** Dims a colour on the shadow pass so drop shadows stay dark. */
vec3 fx_shade(vec3 c) { return fx.isShadow ? c * 0.25 : c; }

/** Distance to the nearest glyph pixel, 0 (on it) .. 1 (a pixel away). */
float fx_distance_to_glyph() {
    float best = 1.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            if (fx_glyph_at(vec2(float(x), float(y))) < 0.1) continue;
            vec2 v = fract(fx.uv * vec2(textureSize(Sampler0, 0)));
            v.x = x == 0 ? 0.0 : (x > 0 ? 1.0 - v.x : v.x);
            v.y = y == 0 ? 0.0 : (y > 0 ? 1.0 - v.y : v.y);
            best = min(best, length(v));
        }
    }
    return best;
}

/**
 * 1 inside the glyph's own box, falling to 0 `pixels` away from it. Pure maths —
 * no texture reads — so it is the cheap way to keep a decoration hugging the text
 * instead of spilling across the whole padded quad.
 */
float fx_halo(float pixels) {
    vec2 outside = max(fx.local - 1.0, -fx.local);
    vec2 inPixels = max(outside, vec2(0.0)) * fx.uvSize * vec2(textureSize(Sampler0, 0));
    return 1.0 - smoothstep(0.0, max(pixels, 0.5), length(inPixels));
}

/**
 * How many pixels below this fragment the glyph starts, searching up to 4 — 0 when
 * there is none. Four texture reads, which is what makes rising effects (flames,
 * mist, ooze) affordable on a screen full of chat.
 */
float fx_pixels_above_glyph() {
    for (int i = 1; i <= 4; i++) {
        if (fx_glyph_at(vec2(0.0, float(i))) >= 0.1) return float(i);
    }
    return 0.0;
}

/**
 * A continuous field coordinate in glyph pixels, shared by every glyph on the
 * line. Particle effects grid on this so the pattern flows across the text
 * instead of repeating identically inside each character.
 */
vec2 fx_field(float cellPixels) {
    return fx.position / max(cellPixels, 0.5);
}

/** True when this fragment sits just outside the glyph, `ring` pixels out. */
bool fx_is_border(float ring) {
    if (fx_glyph_at(vec2(0.0)) >= 0.1) return false;
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            if (abs(float(x)) > ring || abs(float(y)) > ring) continue;
            if (x == 0 && y == 0) continue;
            if (fx_glyph_at(vec2(float(x), float(y))) >= 0.1) return true;
        }
    }
    return false;
}

/* ===========================================================================
   BASE COLOUR
   =========================================================================== */

/** Paints the glyph a flat colour. Almost every effect starts with this. */
void set_color(vec3 c) {
    fx.color.rgb = fx_shade(c);
}

/** Recolours ONLY the drop shadow (no-op on the main pass). */
void set_shadow_color(vec3 c) {
    if (!fx.isShadow) return;
    fx.color.rgb = c;
    fx.topColor.rgb = c;
    fx.backColor.rgb = c;
}

/** Hides the drop shadow entirely - the clean look for glowing / neon text. */
void remove_shadow() {
    if (fx.isShadow) fx.color.a = 0.0;
}

/** Overall opacity, 0..1. */
void set_alpha(float a) {
    fx.color.a *= clamp(a, 0.0, 1.0);
}

void brighten(float amount) { fx.color.rgb = lighten(fx.color.rgb, amount); }
void dim(float amount)      { fx.color.rgb = darken(fx.color.rgb, amount); }

/** amount > 0 boosts saturation, amount = -1 makes it greyscale. */
void saturate_by(float amount) { fx.color.rgb = saturate_color(fx.color.rgb, amount); }

/** Pulls the current colour `amount` (0..1) of the way towards `c`. */
void tint(vec3 c, float amount) {
    fx.color.rgb = blend(fx.color.rgb, fx_shade(c), amount);
}

/* ===========================================================================
   GRADIENTS
   =========================================================================== */

/** Top-to-bottom gradient inside every character. The classic shiny title. */
void gradient_v(vec3 top, vec3 bottom) {
    float t = clamp((fx.uv.y - fx.uvMin.y) / max(fx.uvSize.y, 1.0e-6), 0.0, 1.0);
    fx.color.rgb = fx_shade(blend(top, bottom, t));
}

/**
 * Left-to-right gradient ACROSS THE WHOLE LINE of text. `span` is how many glyph
 * pixels the gradient takes to travel from `left` to `right` (a 16-character
 * name is roughly 96 glyph pixels wide).
 */
void gradient_h(vec3 left, vec3 right, float span) {
    float t = clamp(fx.position.x / max(span, 1.0) + 0.5, 0.0, 1.0);
    fx.color.rgb = fx_shade(blend(left, right, t));
}

void gradient_h(vec3 left, vec3 right) { gradient_h(left, right, 120.0); }

/**
 * The scrolling multi-stop gradient every rank prefix uses. Colours repeat, so
 * the loop is seamless. `speed` in cycles per second (negative scrolls the other
 * way); `scale` stretches the pattern (bigger = wider, lazier bands).
 */
void gradient_2(vec3 a, vec3 b, float speed, float scale) {
    float n = fract(fx.position.x / (400.0 * max(scale, 0.01)) - fx.time * speed * 0.5) * 2.0;
    int i = int(floor(n));
    vec3 c0 = i == 0 ? a : b;
    vec3 c1 = i == 0 ? b : a;
    fx.color.rgb = fx_shade(blend(c0, c1, ease_in_out(fract(n))));
}

void gradient_2(vec3 a, vec3 b) { gradient_2(a, b, 1.0, 1.0); }

void gradient_3(vec3 a, vec3 b, vec3 c, float speed, float scale) {
    vec3 stops[3];
    stops[0] = a; stops[1] = b; stops[2] = c;
    float n = fract(fx.position.x / (400.0 * max(scale, 0.01)) - fx.time * speed * 0.5) * 3.0;
    int i = int(floor(n));
    fx.color.rgb = fx_shade(blend(stops[i], stops[(i + 1) % 3], ease_in_out(fract(n))));
}

void gradient_3(vec3 a, vec3 b, vec3 c) { gradient_3(a, b, c, 1.0, 1.0); }

void gradient_5(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, float speed, float scale) {
    vec3 stops[5];
    stops[0] = a; stops[1] = b; stops[2] = c; stops[3] = d; stops[4] = e;
    float n = fract(fx.position.x / (400.0 * max(scale, 0.01)) - fx.time * speed * 0.5) * 5.0;
    int i = int(floor(n));
    fx.color.rgb = fx_shade(blend(stops[i], stops[(i + 1) % 5], ease_in_out(fract(n))));
}

void gradient_5(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e) { gradient_5(a, b, c, d, e, 1.0, 1.0); }

void gradient_7(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, vec3 f, vec3 g, float speed, float scale) {
    vec3 stops[7];
    stops[0] = a; stops[1] = b; stops[2] = c; stops[3] = d;
    stops[4] = e; stops[5] = f; stops[6] = g;
    float n = fract(fx.position.x / (400.0 * max(scale, 0.01)) - fx.time * speed * 0.5) * 7.0;
    int i = int(floor(n));
    fx.color.rgb = fx_shade(blend(stops[i], stops[(i + 1) % 7], ease_in_out(fract(n))));
}

void gradient_7(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, vec3 f, vec3 g) {
    gradient_7(a, b, c, d, e, f, g, 1.0, 1.0);
}

/** Full-spectrum scrolling rainbow. `saturation` 0..1, `scale` widens the bands. */
void rainbow(float speed, float scale, float saturation) {
    float h = (fx.position.x + fx.position.y) * 0.0025 / max(scale, 0.01) - fx.time * speed * 0.25;
    fx.color.rgb = fx_shade(hsv_to_rgb(vec3(fract(h), clamp(saturation, 0.0, 1.0), 1.0)));
}

void rainbow(float speed) { rainbow(speed, 1.0, 0.75); }
void rainbow()            { rainbow(1.0, 1.0, 0.75); }

/** Keeps the glyph colour but rotates its hue over time. */
void hue_cycle(float speed) {
    vec3 h = rgb_to_hsv(fx.color.rgb);
    h.x = fract(h.x + fx.time * speed * 0.25);
    fx.color.rgb = hsv_to_rgb(h);
}

/* -- Horizontal bands (flags, metal, stripes) ---------------------------- */
// A glyph is exactly 8 pixels tall, so band effects address rows 0..7.

void bands_2(vec3 a, vec3 b) {
    fx.color.rgb = fx_shade(fx_row() < 4.0 ? a : b);
}

void bands_3(vec3 a, vec3 b, vec3 c) {
    float r = fx_row();
    fx.color.rgb = fx_shade(r < 3.0 ? a : (r < 5.0 ? b : c));
}

void bands_4(vec3 a, vec3 b, vec3 c, vec3 d) {
    float r = fx_row();
    fx.color.rgb = fx_shade(r < 2.0 ? a : (r < 4.0 ? b : (r < 6.0 ? c : d)));
}

void bands_5(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e) {
    float r = fx_row();
    fx.color.rgb = fx_shade(r < 2.0 ? a : (r < 3.0 ? b : (r < 5.0 ? c : (r < 6.0 ? d : e))));
}

void bands_6(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, vec3 f) {
    vec3 stops[6];
    stops[0] = a; stops[1] = b; stops[2] = c; stops[3] = d; stops[4] = e; stops[5] = f;
    int i = int(clamp(floor(fx_row() * 6.0 / 8.0), 0.0, 5.0));
    fx.color.rgb = fx_shade(stops[i]);
}

void bands_7(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, vec3 f, vec3 g) {
    vec3 stops[7];
    stops[0] = a; stops[1] = b; stops[2] = c; stops[3] = d;
    stops[4] = e; stops[5] = f; stops[6] = g;
    int i = int(clamp(floor(fx_row() * 7.0 / 8.0), 0.0, 6.0));
    fx.color.rgb = fx_shade(stops[i]);
}

/** Brushed metal: a bright specular row near the top over a darker body. */
void metallic(vec3 light, vec3 dark) {
    float r = fx_row();
    vec3 c = r < 3.0 ? light : (r < 4.0 ? lighten(light, 0.35) : dark);
    fx.color.rgb = fx_shade(c);
}

void metallic(vec3 base) { metallic(base, darken(base, 0.4)); }

/* ===========================================================================
   TIME-BASED COLOUR
   =========================================================================== */

/** Breathes between the current colour and `c`. */
void fade_to(vec3 c, float speed) {
    fx.color.rgb = blend(fx.color.rgb, fx_shade(c), wave01(fx.time * speed * 0.5));
}

void fade_to(vec3 c) { fade_to(c, 1.0); }

/** Hard on/off blink - `speed` blinks per second. */
void blink(float speed) {
    if (fract(fx.time * speed) > 0.5) {
        fx.color.a = 0.0;
        fx.backColor.a = 0.0;
        fx.topColor.a = 0.0;
    }
}

void blink() { blink(1.0); }

/** Irregular brightness flutter, like a failing neon tube. */
void flicker(float speed, float amount) {
    float n = fx_noise(fx.time * speed * 8.0);
    fx.color.rgb = clamp(fx.color.rgb * (1.0 - amount * 0.5 + n * amount), 0.0, 1.0);
}

void flicker() { flicker(1.0, 0.5); }

/** Smooth glow in and out. `amount` 0..1 is how deep the dip goes. */
void pulse_brightness(float speed, float amount) {
    float t = mix(1.0 - clamp(amount, 0.0, 1.0), 1.0 + clamp(amount, 0.0, 1.0) * 0.4,
                  wave01(fx.time * speed * 0.5));
    fx.color.rgb = clamp(fx.color.rgb * t, 0.0, 1.0);
}

void pulse_brightness() { pulse_brightness(1.0, 0.35); }

/**
 * Reveals the line one character at a time, then loops. `charsPerSecond` sets
 * the typing speed and `length` is roughly how many characters the line holds.
 */
void typewriter(float charsPerSecond, float length) {
    float index = fx_char_index();
    float head = mod(fx.time * charsPerSecond, length + 6.0);
    if (index > head) {
        fx.color.a = 0.0;
        fx.backColor.a = 0.0;
        fx.topColor.a = 0.0;
    } else if (abs(index - floor(head)) < 0.5 && fract(fx.time * 2.0) < 0.5) {
        fx.color.rgb = lighten(fx.color.rgb, 0.6);
    }
}

void typewriter() { typewriter(8.0, 24.0); }

/* ===========================================================================
   OUTLINES, GLOWS AND OVERLAYS
   =========================================================================== */

/** A solid 1-pixel border around every glyph. The most readable effect there is. */
void outline(vec3 c) {
    fx.expand = true;
    if (fx.isShadow) {
        fx.color.rgb = c * 0.25;
        return;
    }
    if (fx_is_border(1.0)) fx.backColor = vec4(c, 1.0);
}

/** Like `outline` but only half a pixel thick - subtler on small text. */
void thin_outline(vec3 c) {
    fx.expand = true;
    if (fx.isShadow) {
        fx.color.rgb = c * 0.25;
        return;
    }
    if (fx_glyph_at(vec2(0.0)) >= 0.1) return;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            if (x == 0 && y == 0) continue;
            if (fx_glyph(fx.uv + vec2(float(x), float(y)) * FX_PX * 0.5) >= 0.1) {
                fx.backColor = vec4(c, 1.0);
                return;
            }
        }
    }
}

/** A soft halo bleeding out of the glyph. `strength` 0..1. */
void glow(vec3 c, float strength) {
    fx.expand = true;
    if (fx.isShadow) {
        fx.color = vec4(0.0);
        return;
    }
    float d = fx_distance_to_glyph();
    float falloff = (1.0 - d) * (1.0 - d);
    fx.backColor = vec4(c, clamp(falloff * strength, 0.0, 1.0));
}

void glow(vec3 c) { glow(c, 1.0); }

/** A halo that breathes in and out. */
void pulse_glow(vec3 c, float speed, float strength) {
    glow(c, strength * (0.45 + 0.55 * wave01(fx.time * speed * 0.5)));
}

/** A bright diagonal highlight sweeping across the line. The premium look. */
void shine(float speed, float width, float strength) {
    if (fx.isShadow) return;
    float pos = (1.0 - fx.local.x) + fx.local.y + fx.position.x * 0.004;
    float t = mod(pos + fx.time * speed * 1.6, 2.0);
    float s = 0.0;
    if (t < width) s = smoothstep(0.0, width, t);
    else if (t < width * 2.0) s = smoothstep(width * 2.0, width, t);
    fx.topColor = vec4(1.0, 1.0, 1.0, s * strength);
}

void shine() { shine(1.0, 0.4, 1.0); }

/** Scattered white sparkle pixels drifting over the glyph. */
void shimmer(float speed, float strength) {
    if (fx.isShadow) return;
    float f = fx.local.x + fx.local.y - fx.time * speed * 5.0;
    if (mod(f, 15.0) < 0.7) fx.topColor = vec4(1.0, 1.0, 1.0, strength);
}

void shimmer() { shimmer(1.0, 0.5); }

/** CRT scanlines rolling down the text. `rows` = lines per glyph height. */
void scanlines(float rows, float strength, float speed) {
    if (fx.isShadow) return;
    float s = wave01(fx.local.y * rows + fx.time * speed * 0.5);
    fx.color.rgb = clamp(fx.color.rgb * (1.0 - strength * s), 0.0, 1.0);
}

void scanlines() { scanlines(4.0, 0.45, 1.0); }

/** Split the glyph into two offset colour ghosts. `amount` in glyph pixels. */
void chromatic(float amount, vec3 leftColor, vec3 rightColor) {
    fx.expand = true;
    if (fx.isShadow) return;
    float jitter = (fx_noise(fx.time * 9.0) - 0.5) * 0.6;
    vec2 off = vec2(amount * (1.0 + jitter), 0.0) * FX_PX;
    float a = fx_glyph(fx.uv + off);
    float b = fx_glyph(fx.uv - off);
    vec4 back = vec4(0.0);
    back.rgb = leftColor * a + rightColor * b;
    back.a = max(a, b);
    fx.backColor = back;
}

void chromatic(float amount) { chromatic(amount, rgb(255, 60, 60), rgb(0, 200, 255)); }
void chromatic()             { chromatic(0.6); }

/** Animated static grain over the glyph. */
void grain(float amount, float speed) {
    if (fx.isShadow) return;
    float n = fx_hash(floor(fx.uv * vec2(textureSize(Sampler0, 0))) + floor(fx.time * speed * 20.0));
    fx.color.rgb = clamp(fx.color.rgb * (1.0 - amount + n * amount * 2.0), 0.0, 1.0);
}

void grain() { grain(0.25, 1.0); }

/** Sci-fi projection: tinted, translucent, with rolling interference bars. */
void hologram(vec3 c, float speed) {
    if (fx.isShadow) { fx.color.a = 0.0; return; }
    set_color(c);
    float bar = wave01(fx.local.y * 3.0 + fx.time * speed * 0.8);
    fx.color.rgb = clamp(fx.color.rgb * (0.55 + 0.45 * bar), 0.0, 1.0);
    fx.color.a *= 0.75 + 0.25 * fx_noise(fx.time * speed * 6.0);
    fx.backColor = vec4(c, 0.18);
    fx.expand = true;
}

void hologram(vec3 c) { hologram(c, 1.0); }

/* ===========================================================================
   MOTION
   Every function here nudges `fx.uv`, which slides the glyph inside its
   (expanded) quad. Amplitudes are in glyph pixels: 1.0 is one pixel.
   =========================================================================== */

/** The classic sine wave running along the line. */
void wave(float speed, float amplitude, float frequency) {
    fx.expand = true;
    fx.uv.y += sin(fx.charPos.x * 0.1 * frequency - fx.time * speed * 6.0) * amplitude * FX_PX.y;
}

void wave(float speed) { wave(speed, 1.0, 1.0); }
void wave()            { wave(1.0, 1.0, 1.0); }

/** Nervous per-character jitter. */
void shake(float amount, float speed) {
    fx.expand = true;
    float t = fx.time * speed * 26.0;
    float nx = fx_noise(fx.charPos.x + fx.charPos.y + t) - 0.5;
    float ny = fx_noise(fx.charPos.x - fx.charPos.y + t) - 0.5;
    fx.uv += vec2(nx, ny) * amount * 2.0 * FX_PX;
}

void shake(float amount) { shake(amount, 1.0); }
void shake()             { shake(1.0, 1.0); }

/** Characters spring upward one after another, then rest. */
void hop(float speed, float height, float spacing) {
    fx.expand = true;
    float x = mod(fx.charPos.x * 0.4 - fx.time * speed * 14.0, max(spacing, 0.5) * 5.0 * TAU);
    if (x > TAU) x = TAU;
    fx.uv.y += (-cos(x) * 0.5 + 0.5) * height * FX_PX.y;
}

void hop() { hop(1.0, 1.0, 1.0); }

/** Continuous bouncing - every character on its own arc. */
void bounce(float speed, float height, float spacing) {
    fx.expand = true;
    float t = fract(fx.time * speed - fx.charPos.x * 0.02 * spacing);
    fx.uv.y += (1.0 - abs(sin(t * PI))) * height * FX_PX.y;
}

void bounce() { bounce(1.0, 1.5, 1.0); }

/** Loose drunken wobble in both axes. */
void wobble(float speed, float amount) {
    fx.expand = true;
    float t = fx.time * speed * 3.0 + fx.charPos.x * 0.15;
    fx.uv += vec2(sin(t), cos(t * 1.3)) * amount * FX_PX;
}

void wobble() { wobble(1.0, 0.7); }

/** Rocks each character back and forth around its centre. `amount` in radians. */
void rotate(float speed, float amount) {
    fx.expand = true;
    float a = sin(fx.time * speed * 3.0 + fx.charPos.x * 0.1) * amount;
    fx.uv = fx.uvCenter + rotate2(fx.uv - fx.uvCenter, a);
}

void rotate() { rotate(1.0, 0.25); }

/** Full continuous spin. */
void spin(float speed) {
    fx.expand = true;
    fx.uv = fx.uvCenter + rotate2(fx.uv - fx.uvCenter, fx.time * speed * TAU * 0.5);
}

void spin() { spin(0.5); }

/** Breathing scale. `amount` 0..1 - 0.15 is a lively but readable pulse. */
void scale_pulse(float speed, float amount) {
    fx.expand = true;
    float s = 1.0 - amount * wave01(fx.time * speed * 0.5);
    fx.uv = (fx.uv - fx.uvCenter) * s + fx.uvCenter;
}

void scale_pulse() { scale_pulse(1.0, 0.15); }

/** Characters flip over on their vertical axis, one after another. */
void flip(float speed, float spacing) {
    fx.expand = true;
    float t = mod((fx.charPos.x * 0.4 - fx.time * speed * 14.0) / TAU, max(spacing, 0.2) * 5.0);
    float squash = cos(TAU * min(t, 1.0));
    if (abs(squash) < 0.08) squash = squash < 0.0 ? -0.08 : 0.08;
    fx.uv.x = fx.uvCenter.x + (fx.uv.x - fx.uvCenter.x) / squash;
    fx.uv.y = fx.uvCenter.y + (fx.uv.y - fx.uvCenter.y) / (1.0 + 0.1 * sin(TAU * min(t, 1.0)));
}

void flip() { flip(1.0, 1.0); }

/** A static italic lean. `amount` in glyph pixels of shear at the top. */
void slant(float amount) {
    fx.expand = true;
    fx.uv.x -= (1.0 - fx.local.y) * amount * FX_PX.x;
}

void slant() { slant(1.5); }

/** An animated shear, leaning left and right. */
void skew(float speed, float amount) {
    fx.expand = true;
    fx.uv.x += (1.0 - fx.local.y) * sin(fx.time * speed * 3.0) * amount * FX_PX.x;
    fx.uv.y += cos(fx.time * speed * 3.0) * amount * 0.25 * FX_PX.y;
}

void skew() { skew(1.0, 1.0); }

/** Alternating up / down steps per character. */
void zigzag(float speed, float amount) {
    fx.expand = true;
    float step_ = mod(floor(fx.charPos.x / 6.0) + floor(fx.time * speed * 2.0), 2.0);
    fx.uv.y += (step_ < 1.0 ? -amount : amount) * FX_PX.y;
}

void zigzag() { zigzag(1.0, 1.0); }

/** Slow continuous drift, in glyph pixels per second. */
void drift(float speedX, float speedY, float amount) {
    fx.expand = true;
    fx.uv += vec2(sin(fx.time * speedX), cos(fx.time * speedY)) * amount * FX_PX;
}


/* ===========================================================================
   PROCEDURAL LAYERS
   These paint into `fx.backColor` around the glyph - flames, particles, energy.
   They always skip the shadow pass, and they always request quad expansion.

   Two rules keep them honest. They grid on fx_field(), a coordinate shared by
   every glyph on the line, so the pattern flows across the text instead of
   repeating identically inside each character; and they fade out through
   fx_halo(), so the field hugs the text rather than filling the whole padded
   quad and turning into a solid block of confetti.
   =========================================================================== */

/**
 * Flames licking upward off the top edge of every glyph.
 *
 * The cut rises with height, so the sheet of noise thins into separate tongues
 * instead of a solid block that swallows the word underneath it.
 */
void fire(vec3 hot, vec3 cool, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    if (fx_glyph_at(vec2(0.0)) >= 0.1) return;

    float above = fx_pixels_above_glyph();
    if (above < 0.5) return;

    float heat = 1.0 - (above - 1.0) / 4.5;
    vec2 p = fx_field(1.0);
    float n = fx_noise(vec2(p.x * 0.45, p.y * 0.3 + fx.time * speed * 5.5));
    float cut = 0.54 + (1.0 - heat) * 0.42;
    if (n > cut) fx.backColor = vec4(blend(hot, cool, clamp((n - cut) * 5.0, 0.0, 1.0)), 1.0);
}

void fire() { fire(rgb(255, 51, 51), rgb(255, 179, 77), 1.0); }

/** Slow rolling water or mist drifting off the glyph. */
void water(vec3 deep, vec3 shallow, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    if (fx_glyph_at(vec2(0.0)) >= 0.1) return;

    float above = fx_pixels_above_glyph();
    if (above < 0.5) return;

    float lift = 1.0 - (above - 1.0) / 4.5;
    vec2 p = fx_field(1.4);
    float n = fx_noise(vec2(p.x * 0.5, p.y * 0.4) + vec2(fx.time * speed * 1.1, fx.time * speed * 1.8));
    float cut = 0.55 + (1.0 - lift) * 0.4;
    if (n > cut) fx.backColor = vec4(blend(deep, shallow, clamp((n - cut) * 5.0, 0.0, 1.0)), 1.0);
}

void water() { water(rgb(26, 77, 204), rgb(77, 179, 255), 1.0); }

/** Bubbling slime or toxic ooze, with a pulsing inner glow. */
void ooze(vec3 dark, vec3 bright, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    if (fx_glyph_at(vec2(0.0)) >= 0.1) return;

    float above = fx_pixels_above_glyph();
    if (above < 0.5) return;

    float lift = 1.0 - (above - 1.0) / 4.5;
    float t = fx.time * speed * 2.0;
    vec2 p = fx_field(1.2);
    float n = fx_noise(vec2(p.x * 0.5, p.y * 0.35) + vec2(t * 0.4, t * 0.7)) * 0.7
            + (sin(t * 1.6 + p.x * 0.9) * 0.5 + 0.5) * 0.3;
    float cut = 0.58 + (1.0 - lift) * 0.36;
    if (n > cut) {
        vec3 c = blend(dark, bright, clamp((n - cut) * 5.0, 0.0, 1.0));
        fx.backColor = vec4(c * (0.85 + 0.15 * sin(t * 1.5)), 1.0);
    }
}

void ooze() { ooze(rgb(0, 102, 26), rgb(51, 255, 77), 1.0); }

/** Molten flow: slow, heavy, glowing seams. Recolours the glyph itself. */
void lava(vec3 hot, vec3 crust, float speed) {
    fx.expand = true;
    float f = fx_fbm(fx_field(3.5) + vec2(0.0, -fx.time * speed * 0.6), 3);
    fx.color.rgb = fx_shade(blend(crust, hot, smoothstep(0.35, 0.75, f)));
    if (!fx.isShadow && fx_is_border(1.0)) fx.backColor = vec4(hot, 0.55);
}

void lava() { lava(rgb(255, 140, 20), rgb(90, 20, 10), 1.0); }

/** Crackling energy arcs around the glyph. */
void electric(vec3 c, float speed, float density) {
    fx.expand = true;
    if (fx.isShadow) return;
    if (!fx_is_border(2.0)) return;
    // Coarse cells and a high cut, so the ring reads as a few darting arcs rather
    // than a wall of static clinging to every letter.
    vec2 p = fx_field(2.0);
    float n = fx_noise(p + vec2(fx.time * speed * 6.0, fx.time * speed * 3.0));
    if (n > 1.0 - clamp(density, 0.02, 0.8) * 0.35) {
        fx.backColor = vec4(lighten(c, 0.35), 1.0);
    }
}

void electric() { electric(rgb(120, 200, 255), 1.0, 0.35); }

/* -- Particle fields ------------------------------------------------------ */

/** Twinkling four-point sparkles floating up around the text. */
void sparkles(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(5.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(4.0 / max(density, 0.2));
    p.y -= fx.time * speed * 1.6;
    vec2 cell = floor(p);
    vec2 q = fract(p) - 0.5;
    float seed = fx_hash(cell);
    if (seed < 0.8) return;

    float twinkle = wave01(fx.time * speed * 1.6 + seed * 10.0);
    float star = 1.0 - smoothstep(0.0, 0.18 + 0.12 * twinkle, min(abs(q.x), abs(q.y)) * 2.2 + length(q) * 0.5);
    if (star > 0.05) fx.backColor = vec4(c, star * halo * (0.4 + 0.6 * twinkle));
}

void sparkles() { sparkles(rgb(255, 255, 210), 1.0, 1.0); }

/** Glowing embers drifting upward. */
void embers(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(6.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(3.5 / max(density, 0.2));
    p.y -= fx.time * speed * 2.4;
    p.x += sin(fx.time * speed + p.y * 0.5) * 0.35;
    vec2 cell = floor(p);
    vec2 q = fract(p) - 0.5;
    float seed = fx_hash(cell);
    if (seed < 0.84) return;

    float d = 1.0 - smoothstep(0.10, 0.26, length(q));
    if (d > 0.05) fx.backColor = vec4(blend(c, rgb(255, 240, 200), seed), d * halo);
}

void embers() { embers(rgb(255, 130, 40), 1.0, 1.0); }

/** Soft snowflakes falling past the text. */
void snow(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(6.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(3.5 / max(density, 0.2));
    p.y += fx.time * speed * 1.6;
    p.x += sin(fx.time * speed * 0.8 + p.y) * 0.3;
    vec2 cell = floor(p);
    vec2 q = fract(p) - 0.5;
    float seed = fx_hash(cell);
    if (seed < 0.86) return;

    float d = 1.0 - smoothstep(0.08, 0.22, length(q));
    if (d > 0.05) fx.backColor = vec4(c, d * halo * 0.9);
}

void snow() { snow(rgb(235, 245, 255), 1.0, 1.0); }

/** Rising hearts, alternating between the two colours. */
void hearts(vec3 a, vec3 b, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(6.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(5.0 / max(density, 0.2));
    p.y -= fx.time * speed * 1.2;
    p.x += sin(fx.time * speed * 0.5 + p.y * 0.6) * 0.3;
    vec2 cell = floor(p);
    float seed = fx_hash(cell);
    if (seed < 0.72) return;

    vec2 q = (fract(p) - 0.5) * 3.2;
    q.y = -q.y + 0.35;
    float d = q.x * q.x + (q.y - abs(q.x) * 0.5) * (q.y - abs(q.x) * 0.5) - 1.0;
    float shape = smoothstep(0.2, -0.2, d) * smoothstep(-1.2, -1.0, q.y);
    if (shape <= 0.12) return;

    fx.backColor = vec4(seed < 0.86 ? a : b, shape * halo);
}

void hearts() { hearts(rgb(255, 26, 90), rgb(255, 115, 165), 1.0, 1.0); }

/** Slow twinkling starfield behind the text. */
void stars(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(6.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(3.0 / max(density, 0.2));
    vec2 cell = floor(p);
    vec2 q = fract(p) - 0.5;
    float seed = fx_hash(cell);
    if (seed < 0.85) return;

    float t = wave01(fx.time * speed * 0.5 + seed * 12.0);
    float d = 1.0 - smoothstep(0.04, 0.18, length(q));
    if (d > 0.03) fx.backColor = vec4(c, d * halo * (0.25 + 0.75 * t));
}

void stars() { stars(rgb(255, 255, 255), 1.0, 1.0); }

/** Air bubbles rising, as if the text were underwater. */
void bubbles(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(6.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(4.0 / max(density, 0.2));
    p.y -= fx.time * speed * 1.8;
    p.x += sin(fx.time * speed * 1.2 + p.y * 1.2) * 0.25;
    vec2 cell = floor(p);
    vec2 q = fract(p) - 0.5;
    float seed = fx_hash(cell);
    if (seed < 0.82) return;

    float ring = abs(length(q) - (0.12 + seed * 0.12));
    float d = 1.0 - smoothstep(0.0, 0.07, ring);
    if (d > 0.05) fx.backColor = vec4(c, d * halo * 0.85);
}

void bubbles() { bubbles(rgb(190, 235, 255), 1.0, 1.0); }

/** Drifting smoke or fog, softest of the fields. */
void smoke(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(5.0);
    if (halo <= 0.02) return;

    float f = fx_fbm(fx_field(4.0 / max(density, 0.2)) + vec2(fx.time * speed * 0.3, -fx.time * speed * 0.6), 3);
    float alpha = smoothstep(0.42, 0.8, f) * halo;
    if (alpha > 0.02) fx.backColor = vec4(c, alpha * 0.7);
}

void smoke() { smoke(rgb(180, 180, 190), 1.0, 1.0); }

/** Shifting aurora curtains coloured through three stops. Recolours the glyph. */
void aurora(vec3 a, vec3 b, vec3 c, float speed) {
    float f = fx_fbm(vec2(fx.position.x * 0.012, fx.local.y * 1.6) + vec2(fx.time * speed * 0.4, 0.0), 3);
    vec3 col = f < 0.5 ? blend(a, b, f * 2.0) : blend(b, c, (f - 0.5) * 2.0);
    fx.color.rgb = fx_shade(col);
}

void aurora() { aurora(rgb(0, 255, 170), rgb(60, 130, 255), rgb(190, 90, 255), 1.0); }

/** Faint arcane marks flickering around the text. */
void magic_runes(vec3 c, float density, float speed) {
    fx.expand = true;
    if (fx.isShadow) return;
    float halo = fx_halo(5.0);
    if (halo <= 0.02) return;

    vec2 p = fx_field(3.0 / max(density, 0.2));
    p.y += fx.time * speed * 0.6;
    vec2 cell = floor(p);
    vec2 q = fract(p);
    float seed = fx_hash(cell);
    if (seed < 0.86) return;

    float bar = step(0.35, q.x) * step(q.x, 0.65) + step(0.35, q.y) * step(q.y, 0.65);
    if (bar < 0.5) return;

    float t = wave01(fx.time * speed * 0.7 + seed * 7.0);
    fx.backColor = vec4(c, halo * (0.3 + 0.5 * t));
}

void magic_runes() { magic_runes(rgb(190, 140, 255), 1.0, 1.0); }

#endif
