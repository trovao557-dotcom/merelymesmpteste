MerelyMeSMP Rank Menu Test v1

Client test pack for Minecraft 1.21.11 Fabric + OptiGUI.
Based on MerelyMeSMP-Menu-Ranks-BanHammer-v5.1-Fixed.
The BanHammer assets are preserved.

The new blue GUI activates only for a large chest whose title contains RANK MENU TEST. Ordinary containers and current server menus are not changed by this test rule.

Install the ZIP locally, enable it above other GUI packs, then load the separate ranks-menu-test.sk script to use /ranksmenutest.
